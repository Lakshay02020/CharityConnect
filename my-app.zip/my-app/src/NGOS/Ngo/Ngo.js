import React, { useEffect, useState } from "react"
import image from './tesla.jpg'
import { useParams } from "react-router-dom"

const Ngo = (props) => {
    

    return (
        
        <div className="card" style={{
            width: '18rem', color: '#2a76b1', margin: '40px 24px'
        }}>
            <div className="logo" style={{
                width: '40%',
                margin: '30px auto 9px auto',
                height: 'fit-content'
            }}>
                <img style={{
                    height: '113px',
                    borderRadius: '10px'
                }} src={image} className="card-img-top" alt="..." />
            </div>

            <div className="card-body" >
                <h5 className="card-title">{props.ngo.name} </h5>
                {/* <p className="card-text" style={{ display: 'flex', width: '100%', flexWrap: 'wrap', justifyContent: 'center' }}>
                    {props.ngo.tags.map((tag, index) => (

                        <h4><span class="badge bg-secondary" style={{
                            margin: '4px',
                            fontWeight: 500,
                            fontSize: 'medium'
                        }}>hello</span></h4>

                    ))}


                </p> */}
                <div style={{ display: "flex", width: '100%', justifyContent: 'center' }}>
                    <a href="" className="btn btn-primary" style={{
                        width: '5.5rem',
                        height: 'fit-content',
                        color: '#3795de',
                        background: '#d6ebff',
                        border: 'none',
                        borderRadius: '27px',
                        padding: '2px 10px',
                        fontWeight: 600,
                        margin: '0px 16px'
                    }}> members</a>

                    <a href="" className="btn btn-primary" style={{
                        width: '5.5rem',
                        height: 'fit-content',
                        color: '#3795de',
                        background: '#d6ebff',
                        border: 'none',
                        borderRadius: '27px',
                        padding: '2px 10px',
                        fontWeight: 600,
                        margin: '0px 16px'
                    }}>visit</a>
                </div>
            </div>
        </div>
    )
}

export default Ngo