

const EventCard=(props)=>{
  
  console.log(props.event);
    return(
        <div className="card" style={{width:'18rem'}}>
  <img src="..." className="card-img-top" alt="..."/>
  <div className="card-body">
    <h5 className="card-title">jhdfdijsnkisjnij</h5>
   
    <p className="card-text"></p>
    <div></div>
    <div></div>
    <a href="#" className="btn btn-primary">Join</a>
  </div>
</div>
    )
}

export default EventCard